1.The project is created on AndroidStudio 2.0 version.
2.Images are stored in drawable folder. I am using separate images for thumbnail and full-view.
3.I fixed the view mode to portrait on each view.
