(1) Minimum SDK is API 18
(2) My project package name is edu.scu.qjiang.mortgagecalculator
(3) In the landscape view, you can scroll down to see additional texts. In the simulator, when you try to scroll down, you need to click on the screen, then drag to scroll.

