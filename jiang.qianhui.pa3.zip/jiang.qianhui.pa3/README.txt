1. Images are stored in /storage/emulated/0/Pictures/Photo-Notes
2. I used thumbnail in the list view, and full image in addPhoto and viewPhoto activities
3. The "Add" button goes to the "Add Photo" activity first, then after you click "Take Photo", it launches camera then
4. I implemented 6.0 run-time permission request
5. I support both viewing modes, and implemented it with a scrollView
6. Yes, I implemented the bonus feature. The newly added notes appears on top of the recycler view
7. The app supports empty caption note, but it requires the user to take a photo.
8. I only implemented the action bar in list view.
